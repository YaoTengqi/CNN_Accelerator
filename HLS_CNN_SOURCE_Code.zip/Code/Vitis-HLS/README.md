# Vitis-HLS

## create_project.tcl

Create the Vitis HLS (version 2020.2) project including directives for pipelining and stream-dataflow optimizations.

### Usage

```
vitis_hls -f create_project.tcl
```
