# C

### Debug code

```
make dbg_cnn # Compilation.
./dbg_cnn    # Execution.
```

### Optimized code

```
make cnn # Compilation.
./cnn    # Execution.
```
