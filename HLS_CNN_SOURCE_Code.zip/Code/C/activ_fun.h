#pragma once

#include "definitions.h"

float relu (float x);

void soft_max(float dense_array [DIGITS], float pred[DIGITS]);
