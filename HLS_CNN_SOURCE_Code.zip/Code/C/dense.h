#pragma once

#include "definitions.h"

void
dense_layer
(
  float flat_array  [FLAT_SIZE],
  float dense_array [DENSE_SIZE]
);
